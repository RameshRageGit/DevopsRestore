package x;

public interface Shape {
	public int sides();
	
	public int circumference();

}
