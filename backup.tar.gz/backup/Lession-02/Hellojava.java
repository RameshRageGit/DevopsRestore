ass HelloJava {

public static void main(String args[]){

System.out.Println(“ I am your Java Program. Thank you! ”);

}

}


