 am your JavaScript Program”;

console.log(texts);


