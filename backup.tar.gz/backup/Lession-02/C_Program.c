nclude<stdio.h>

int main(){

printf(“Hello! I am C-Program. Thank you!”);

return 0;

}


